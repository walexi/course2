How to run this application

to install the dependencies and create an environment
`make install`

to run the tests
`make test`

to run the application
`make run`

Please note that to run this application or run the tests, you need to set the following environment either directly in your environment or in the Makefile
API_KEY=  # api key to access google gemini
PROMETHEUS_MULTIPROC_DIR= # directory to write prometheus files